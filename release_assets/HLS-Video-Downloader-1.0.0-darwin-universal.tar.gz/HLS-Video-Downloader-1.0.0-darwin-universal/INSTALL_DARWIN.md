# macOS Installation Instructions

## Quick Start
1. Extract this archive
2. Open Terminal in the extracted folder
3. Run: `./install.sh`
4. Launch from Applications folder

## Requirements
- macOS 10.14 (Mojave) or later
- 200 MB free disk space
- Internet connection (for initial setup)

## Manual Installation
1. Install Python 3.8+ (if not already installed)
2. Open Terminal in this folder
3. Run: `python3 installer.py`

## Troubleshooting
- Allow app in System Preferences > Security & Privacy
- Grant Terminal permissions if prompted
- Use `chmod +x install.sh` if permission denied
