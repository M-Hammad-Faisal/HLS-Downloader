# Windows Installation Instructions

## Quick Start
1. Extract this ZIP file to a folder
2. Double-click `install.bat`
3. Follow the installation prompts
4. Launch from desktop shortcut

## Requirements
- Windows 7/8/10/11
- 200 MB free disk space
- Internet connection (for initial setup)

## Manual Installation
If the automatic installer doesn't work:
1. Install Python 3.8+ from python.org
2. Open Command Prompt in this folder
3. Run: `python installer.py`

## Troubleshooting
- Run as Administrator if installation fails
- Disable antivirus temporarily if blocked
- Check Windows Defender exclusions
