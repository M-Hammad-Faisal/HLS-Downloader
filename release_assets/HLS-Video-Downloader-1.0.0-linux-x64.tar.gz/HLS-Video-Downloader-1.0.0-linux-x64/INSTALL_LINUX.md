# Linux Installation Instructions

## Quick Start
1. Extract this archive
2. Open terminal in the extracted folder
3. Run: `./install.sh`
4. Launch from desktop shortcut

## Requirements
- Ubuntu 18.04+ / Debian 10+ / CentOS 7+ / Fedora 30+
- Python 3.8+ (usually pre-installed)
- 200 MB free disk space
- Internet connection (for initial setup)

## Manual Installation
1. Ensure Python 3.8+ is installed: `python3 --version`
2. Run: `python3 installer.py`

## Troubleshooting
- Install Python: `sudo apt install python3 python3-pip` (Ubuntu/Debian)
- Make executable: `chmod +x install.sh`
- Check dependencies: `python3 -m pip --version`
