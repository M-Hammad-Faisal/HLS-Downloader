"""HLS Downloader package: modular HTTP/HLS downloader and GUI."""

__all__ = [
    "hls",
    "http_dl",
    "utils",
]

__version__ = "0.1.0"